/*
	Place holder for Algorithm for Non-Tunneling Monsters
	
	Note: This will be combined with PathP1.c after the Submission of Assignment A_1.03.
*/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdint.h>

#include "Dungeonio.h"
#include "heap.h"

typedef struct corridor_path {
  heap_node_t *hn;
  //uint8_t pos[2];
  uint8_t xpos;
  uint8_t ypos;
  //uint8_t from[2];
  int32_t cost;
} corridor_path_t;

uint8_t **costmap;

//uint8_t **costmap1;

static void dijkstra_monster(struct Dungeon *d, int goal_x, int goal_y, int tunnel);

void printPaths(struct Dungeon *d);

uint8_t** TunnelPath(struct Dungeon *d, int print, int goal_x, int goal_y) {

  costmap = malloc(sizeof(uint8_t *)*HEIGHT);
  int k;
  for (k = 0; k < HEIGHT; k++) {
    costmap[k] = malloc(WIDTH*sizeof(uint8_t));
  }
  
  dijkstra_monster(d, goal_x, goal_y, 1);
  if (print) {
    printPaths(d);
  }
  
  return costmap;
}

uint8_t** Non_TunnelPath(struct Dungeon *d, int print, int goal_x, int goal_y) {

  costmap = malloc(HEIGHT*sizeof(uint8_t *));
  int k;
  for (k = 0; k < HEIGHT; k++) {
    costmap[k] = malloc(WIDTH*sizeof(uint8_t));
  }
  
  dijkstra_monster(d, goal_x, goal_y, 0);
  if (print) {
    printPaths(d);
  }
  
   return costmap;
}

static int32_t corridor_path_cmp(const void *key, const void *with) {
  return ((corridor_path_t *) key)->cost - ((corridor_path_t *) with)->cost;
}

static void dijkstra_monster(struct Dungeon *d, int goal_x, int goal_y, int tunnel)
{
  static corridor_path_t path[HEIGHT][WIDTH], *p;
  static uint32_t initialized = 0;
  heap_t h;
  uint32_t x, y;

  if (!initialized) {
    for (y = 0; y < HEIGHT; y++) {
      for (x = 0; x < WIDTH; x++) {
        path[y][x].ypos = y;
        path[y][x].xpos = x;
      }
    }
    initialized = 1;
  }
  
  for (y = 0; y < HEIGHT; y++) {
    for (x = 0; x < WIDTH; x++) {
      path[y][x].cost = INT_MAX;
    }
  }

  //path[from[dim_y]][from[dim_x]].cost = 0;
  //printf("MAde it here!\n");
  path[goal_y][goal_x].cost = 0;
  //printf("y: %d, x: %d\n", d->PC_y, d->PC_x);

  heap_init(&h, corridor_path_cmp, NULL); //include this as well! DONE

  //printf("Made it here!\n");
  for (y = 0; y < HEIGHT; y++) {
    for (x = 0; x < WIDTH; x++) {
      //printf("Hardness at y = %d, x = %d is : %d\n", y, x, d->dungeon_hardness[y][x]);
      if (tunnel) {
	if (d->dungeon_hardness[y][x] != 255) {
      //if (mapxy(x, y) != ter_wall_immutable) {
	  path[y][x].hn = heap_insert(&h, &path[y][x]);
	} else {
	  path[y][x].hn = NULL;
	}
      } else {
	if (d->dungeon[y][x] != ' ') {
	  //if (mapxy(x, y) != ter_wall_immutable) {
	  path[y][x].hn = heap_insert(&h, &path[y][x]);
	} else {
	  path[y][x].hn = NULL;
	}
      }
    }
  }

  //printf("MAde it here!\n");
  int counter = 0;
  while ((p = heap_remove_min(&h))) {
    //printf("%d\n", counter);
    //counter++;
    //printf("ypos = %d, xpos = %d\n", p->ypos, p->xpos);
    //printPaths(d);
    p->hn = NULL;

    /* if (p->ypos == goal_y && p->xpos == goal_x) { */
    /*   heap_delete(&h); */
    /*   return; */
    /* } */

    if ((path[p->ypos - 1][p->xpos    ].hn) &&
        (path[p->ypos - 1][p->xpos    ].cost >
         p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1))) {
      path[p->ypos - 1][p->xpos    ].cost =
        p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1);
      //printf("hardness at x = %d, y = %d: %d\n", p->xpos, p->ypos, d->dungeon_hardness[p->ypos][p->xpos]/85+1);
      //path[p->ypos - 1][p->xpos    ].from[dim_y] = p->pos[dim_y];
      //path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      //printf("1\n");
      heap_decrease_key_no_replace(&h, path[p->ypos - 1]
                                           [p->xpos    ].hn);
    }
    if ((path[p->ypos - 1][p->xpos - 1].hn) &&
        (path[p->ypos - 1][p->xpos - 1].cost >
         p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1))) {
      path[p->ypos - 1][p->xpos - 1].cost =
        p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1);
      //path[p->ypos - 1][p->xpos    ].from[dim_y] = p->pos[dim_y];
      //path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      //printf("2\n");
      heap_decrease_key_no_replace(&h, path[p->ypos - 1]
                                           [p->xpos - 1].hn);
    }
    if ((path[p->ypos    ][p->xpos - 1].hn) &&
        (path[p->ypos    ][p->xpos - 1].cost >
         p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1))) {
      path[p->ypos    ][p->xpos - 1].cost =
        p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1);
      //path[p->ypos - 1][p->xpos    ].from[dim_y] = p->pos[dim_y];
      //path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      //printf("3\n");
      heap_decrease_key_no_replace(&h, path[p->ypos    ]
                                           [p->xpos - 1].hn);
    }
    if ((path[p->ypos + 1][p->xpos - 1].hn) &&
        (path[p->ypos + 1][p->xpos - 1].cost >
         p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1))) {
      path[p->ypos + 1][p->xpos - 1].cost =
        p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1);
      //path[p->ypos - 1][p->xpos    ].from[dim_y] = p->pos[dim_y];
      //path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      //printf("4\n");
      heap_decrease_key_no_replace(&h, path[p->ypos + 1]
                                           [p->xpos - 1].hn);
    }
    if ((path[p->ypos + 1][p->xpos    ].hn) &&
        (path[p->ypos + 1][p->xpos    ].cost >
         p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1))) {
      path[p->ypos + 1][p->xpos    ].cost =
        p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1);
      //path[p->ypos - 1][p->xpos    ].from[dim_y] = p->pos[dim_y];
      //path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      //printf("5\n");
      heap_decrease_key_no_replace(&h, path[p->ypos + 1]
                                           [p->xpos    ].hn);
    }
    if ((path[p->ypos + 1][p->xpos + 1].hn) &&
        (path[p->ypos + 1][p->xpos + 1].cost >
         p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1))) {
      path[p->ypos + 1][p->xpos + 1].cost =
        p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1);
      //path[p->ypos - 1][p->xpos    ].from[dim_y] = p->pos[dim_y];
      //path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      //printf("6\n");
      heap_decrease_key_no_replace(&h, path[p->ypos + 1]
                                           [p->xpos + 1].hn);
    }
    if ((path[p->ypos    ][p->xpos + 1].hn) &&
        (path[p->ypos    ][p->xpos + 1].cost >
         p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1))) {
      path[p->ypos    ][p->xpos + 1].cost =
        p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1);
      //path[p->ypos - 1][p->xpos    ].from[dim_y] = p->pos[dim_y];
      //path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      //printf("7\n");
      heap_decrease_key_no_replace(&h, path[p->ypos    ]
                                           [p->xpos + 1].hn);
    }
    if ((path[p->ypos - 1][p->xpos + 1].hn) &&
        (path[p->ypos - 1][p->xpos + 1].cost >
         p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1))) {
      path[p->ypos - 1][p->xpos + 1].cost =
        p->cost + (d->dungeon_hardness[p->ypos][p->xpos]/85 + 1);
      //path[p->ypos - 1][p->xpos    ].from[dim_y] = p->pos[dim_y];
      //path[p->pos[dim_y] - 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x];
      //printf("8\n");
      heap_decrease_key_no_replace(&h, path[p->ypos - 1]
                                           [p->xpos + 1].hn);
    }
    
    /* if ((path[p->pos[dim_y]    ][p->pos[dim_x] - 1].hn) && */
    /*     (path[p->pos[dim_y]    ][p->pos[dim_x] - 1].cost > */
    /*      p->cost + hardnesspair(p->pos))) { */
    /*   path[p->pos[dim_y]    ][p->pos[dim_x] - 1].cost = */
    /*     p->cost + hardnesspair(p->pos); */
    /*   path[p->pos[dim_y]    ][p->pos[dim_x] - 1].from[dim_y] = p->pos[dim_y]; */
    /*   path[p->pos[dim_y]    ][p->pos[dim_x] - 1].from[dim_x] = p->pos[dim_x]; */
    /*   heap_decrease_key_no_replace(&h, path[p->pos[dim_y]    ] */
    /*                                        [p->pos[dim_x] - 1].hn); */
    /* } */
    /* if ((path[p->pos[dim_y]    ][p->pos[dim_x] + 1].hn) && */
    /*     (path[p->pos[dim_y]    ][p->pos[dim_x] + 1].cost > */
    /*      p->cost + hardnesspair(p->pos))) { */
    /*   path[p->pos[dim_y]    ][p->pos[dim_x] + 1].cost = */
    /*     p->cost + hardnesspair(p->pos); */
    /*   path[p->pos[dim_y]    ][p->pos[dim_x] + 1].from[dim_y] = p->pos[dim_y]; */
    /*   path[p->pos[dim_y]    ][p->pos[dim_x] + 1].from[dim_x] = p->pos[dim_x]; */
    /*   heap_decrease_key_no_replace(&h, path[p->pos[dim_y]    ] */
    /*                                        [p->pos[dim_x] + 1].hn); */
    /* } */
    /* if ((path[p->pos[dim_y] + 1][p->pos[dim_x]    ].hn) && */
    /*     (path[p->pos[dim_y] + 1][p->pos[dim_x]    ].cost > */
    /*      p->cost + hardnesspair(p->pos))) { */
    /*   path[p->pos[dim_y] + 1][p->pos[dim_x]    ].cost = */
    /*     p->cost + hardnesspair(p->pos); */
    /*   path[p->pos[dim_y] + 1][p->pos[dim_x]    ].from[dim_y] = p->pos[dim_y]; */
    /*   path[p->pos[dim_y] + 1][p->pos[dim_x]    ].from[dim_x] = p->pos[dim_x]; */
    /*   heap_decrease_key_no_replace(&h, path[p->pos[dim_y] + 1] */
    /*                                        [p->pos[dim_x]    ].hn); */
    /* } */
  }
  int Height, Width;
  //printf("Made it here\n");
  for (Height = 0; Height < HEIGHT; Height++) {
    for (Width = 0; Width < WIDTH; Width++) {
      costmap[Height][Width] = path[Height][Width].cost;
    }
  }
}

void printPaths(struct Dungeon *d) {
  int height, width;
  for (height = 1; height < HEIGHT-1; height++) {
    for  (width = 1; width < WIDTH-1; width++) {
      if (height == d->PC_y && width == d->PC_x) {
	printf("@");
      } else if(costmap[height][width] == INT_MAX)
	  {
		  printf("%c", ' ');
	  }
	  else
	  {
      printf("%d", costmap[height][width]%10);
      }
    }
    printf("\n");
  }
}

