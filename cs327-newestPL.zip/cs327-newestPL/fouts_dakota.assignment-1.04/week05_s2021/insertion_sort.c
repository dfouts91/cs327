#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void insertion_sort(int *a, int n)
{
  int i, j, t;

  for (i = 1; i < n; i++) {
    for (t = a[i], j = i - 1; j > -1 && a[j] > t; j--) {
      a[j + 1] = a[j];
    }
    a[j + 1] = t;
  }
}

void insertion_sort_generic(void *data, int n, size_t s,
                            int (*compare)(const void *, const void *))
{
  char *a;
  int i, j;
  void *t;

  a = data;
  t = malloc(s);

  for (i = 1; i < n; i++) {
    for (memcpy(t, a + i * s, s), j = i - 1;
         j > -1 && compare(a + j * s, t) > 0;
         j--) {
      memcpy(a + (j + 1) * s, a + j * s, s);
    }
    memcpy(a + (j + 1) * s, t, s);
  }

  free(t);
}

int compare_int(const void *v1, const void *v2)
{
  return *((int *) v1) - *((int *) v2);
}

int compare_float(const void *v1, const void *v2)
{
  return *((float *) v1) - *((float *) v2);
}

int compare_string(const void *v1, const void *v2)
{
  return strcmp(*(char **) v1, *(char **) v2);
}

int main(int argc, char *argv[])
{
  int a[] = {10,9,8,7,6,5,4,3,2,1};
  float f[] = {0.0001, 1};
  int i;

  char *s[]= {"one","two","three","four","five",
              "six","seven","eight","nine","ten"};

  //  insertion_sort(a, sizeof (a) / sizeof (a[0]));

  insertion_sort_generic(a, 10, sizeof (int), compare_int);

  for (i = 0; i < 10; i++) {
    printf("%d ", a[i]);
  }
  printf("\n");

  insertion_sort_generic(f, 10, sizeof (float), compare_int);

  for (i = 0; i < 10; i++) {
    printf("%f ", f[i]);
  }
  printf("\n");

  insertion_sort_generic(s, 10, sizeof (char *), compare_string);

  for (i = 0; i < 10; i++) {
    printf("%s ", s[i]);
  }
  printf("\n");

  return 0;
}
