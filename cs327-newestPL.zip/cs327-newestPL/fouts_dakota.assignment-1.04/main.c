#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ncurses.h>
#include "Dungeonio.h"

struct Dungeon d;
struct Dungeon d2;
uint8_t nummon = 10;

int LOAD = 0;
int SAVE = 0;

int onStairs = 0;

void io_init_terminal(void);
int getInput(void);
void io_deinit_terminal(void);
void printScreen(struct Dungeon *d);
void OpenMonsterMenu(struct Dungeon *d);
void openCharacterMenu(struct Dungeon *d);
void movePC(struct Dungeon *d, int y_dir, int x_dir);


int main(int argc, char *argv[])
{
  char *home = getenv("HOME");
  char *game_dir = ".rlg327";
  char *save_fold = "dungeon";
  char *path = malloc(strlen(home) + strlen(game_dir) + strlen(save_fold) + 2 + 1);
  sprintf(path, "%s/%s/%s", home, game_dir, save_fold);
  
  int i;
  //printf("Arguments: %d\n", argc);
  for (i = 1; i < argc; i++) {
    //printf("%s\n", argv[i]);
    if (!strcmp(argv[i], "--load")) {
      LOAD = 1;
    }
    if (!strcmp(argv[i], "--save")) {
      SAVE = 1;
    }
    if (!strcmp(argv[i], "--nummon")) {
      //printf("Made it here!\n");
      char *Nummon = argv[i+1];
      nummon = atoi(Nummon);
    }
  }
  //printf("Number of monsters is: %d\n", nummon);

  if (LOAD == 1) {
    d = Load_Dungeon(path);
  } else {
    d = Generate_Dungeon();
    //d = Generate_Dungeon();
  }
  //printf("Made it here?\n");
  d.nummon = nummon;
  AddMonsters_new(&d);
  //heap_t mon_heap = AddMonsters(&d, nummon);
  //d.monster_heap = &mon_heap;// = AddMonsters(&d, nummon);
  
  /*int input;
  io_init_terminal();
  bool ext = 0;
  while(1)
  {
	  printScreen(&d);
	  input = getInput();
	  
	  switch(input)
	  {
		  //Number Pad
		  {
		  case 061: //1: down-left
		  movePC(&d, 1, -1);
		  break;
		  case 062: //2: down
		  movePC(&d, 1, 0);
		  break;
		  case 063: //3: down-right
		  movePC(&d, 1, 1);
		  break;
		  case 064: //4: left
		  movePC(&d, 0, -1);
		  break;
		  case 065: //5: rest
		  movePC(&d, 0,0);
		  break;
		  case 066: //6: right
		  movePC(&d, 0, 1);
		  break;
		  case 067: //7: up-left
		  movePC(&d, -1, -1);
		  break;
		  case 070: //8: up
		  movePC(&d, -1, 0);
		  break;
		  case 071: //9: up-right
		  movePC(&d, -1, 1);
		  break;
		  }
		  //Keyboard: Lower Case
		  {
		  case 0142: //b: down-left
		  movePC(&d, 1, -1);
		  break;
		  case 0143: //c: Display Charater Info
		  openCharacterMenu(&d);
		  break;
		  case 0144: //d: Drop Item
		  mvprintw(22, 1, "Drop Item not yet supported");
		  break;
		  case 0145: //e: Display Equipment
		  mvprintw(22, 1, "Equipment Display not yet available");
		  break;
		  case 0146: //f: Fog of war
		  mvprintw(22, 1, "Fog of war not supported yet");
		  break;
		  case 0147: //g: Teleport
		  mvprintw(22, 1, "Teleport not yet supported");
		  break;
		  case 0150: //h: Move left
		  movePC(&d, 0, -1);
		  break;
		  case 0151: //i: Display inventory
		  mvprintw(22, 1, "Inventory not supported yet");
		  break;
		  case 0152: //j: Move down
		  movePC(&d, 1, 0);
		  break;
		  case 0153: //k: Move up
		  movePC(&d, -1, 0);
		  break;
		  case 0154: //l: Move right
		  movePC(&d, 0, 1);
		  break;
		  case 0155: //m: Open Monster Menu
		  OpenMonsterMenu(&d);
		  break;
		  case 0156: //n: Move down-right
		  movePC(&d, 1, 1);
		  break;
		  case 0163: //s: Display Terrain Map
		  mvprintw(22, 1, "TODO: Terrain Map");
		  break;
		  case 0164: //t: Take off item
		  mvprintw(22, 1, "Removal of items not yet supported");
		  break;
		  case 0165: //u: Move up-right
		  movePC(&d, -1, 1);
		  break;
		  case 0167: //w: wear item
		  mvprintw(22, 1, "Wearing items is not yet supported");
		  break;
		  case 0170: //x: Explunge Item
		  mvprintw(22, 1, "Explunging items is not yet supported");
		  break;
		  case 0171: //y: Move up-left
		  movePC(&d, -1, -1);
		  break;
		  }
		  //TODO: Finish Uppercase letters
		  {
		  case 0121: //Q: Quit
		  ext = 1;
		  break;
		  }
		  //TODO: Add Special keys
		  {}
		  default: //Invalid Command
		  mvprintw(22, 1, "Command not found: %5o", input);
		  break;
	  }

	  int z;
	  for (z = 0; z < d.numRooms; z++) {
	    struct Room r = d.Rooms[z];
	    if (d.PC_x <= r.x + r.w && d.PC_x >= r.x && d.PC_y <= r.y + r.h && d.PC_y >= r.y) {
	      d.PC_room = z;
	      //printf("PC room: %d\n", d.PC_room);
	    }
	  }
	  
	  if (onStairs == 1) {
	    printf("\n If statement activated \n");
	    d = Generate_Dungeon();
	    printf("\n Made it here! \n");
	    AddMonsters_new(&d);
	    printf("\n Actually, made it here! \n");
	    printScreen(&d);
	    onStairs == 0;
	  }

	  //UpdateMonsters_new(&d);
	  
	  if(ext == 1) break;
	  
	  //UpdateMonsters_new(&d);
  }
  
  io_init_terminal();
  getInput();
  io_deinit_terminal();
  return 0;*/
  
  printMapWithMonsters(&d);

  int counter = 0;
  while (counter < 10 && d.PC_isAlive) {//d.PC_isAlive) {
    printf("%dth time around\n", ++counter);
    //mon_heap = UpdateMonsters(&d);
	UpdateMonsters_new(&d);
    //d.monster_heap = &mon_heap; //= UpdateMonsters(&d);
    usleep(100000);
    //if (counter%20 == 0) {
      printMapWithMonsters(&d);
      //}
  }
  if (counter == 10) {
    printf("\tYou survived 4000 turns, good job!\n");
  } else {
    printf("\n\t\tYou died! You lose! This was the final dungeon state ^\n\n\n");
  }
  //printMapWithMonsters(&d);

  //printf("nummon is %d\n", nummon);
  
  if (SAVE == 1) {
    Save_Dungeon(path, &d);
  }

  return 0;  
}
void io_init_terminal(void)
{
	initscr();
	raw();
	noecho();
	curs_set(0);
	keypad(stdscr, TRUE);
}
void io_deinit_terminal(void)
{
	endwin();
}
int getInput(void)
{
	return getch();
}
void printScreen(struct Dungeon *d)
{
	for(int i = 0; i < HEIGHT; i++)
	{
		for(int j = 0; j < WIDTH; j++)
		{
			mvaddch(i, j, (d->monsters[i][j] == 0 ? d->dungeon[i][j] : d->monsters[i][j]));
		}
	}
}
void OpenMonsterMenu(struct Dungeon *d)
{
	int starting_index = 0, input = 0;
	int number_of_monsters = 0;
	int l;
	for (l = 0; l < d->nummon; l++) {
	  monster_t mon = d->Monsters[nummon];
	  if (!mon.isDead) {
	    number_of_monsters++;
	  }
	}
	//printf("\n Number of monsters: %d \n", number_of_monsters);
	mvprintw(2, 10, "     %3s%d%s",/* sizeof(d->Monsters)/sizeof(d->Monsters[0]),*/"You know of ", number_of_monsters, " Monsters");
	mvprintw(3, 10, "     %35s", "");
	bool ext_menu = 0;
	
	while(1)
	{
		for(int i = 0; i < 15; i++)
		{
			if(i + starting_index < d->nummon)
			{
				mvprintw(i+4, 10, "%3d: %7s%3d:%3d%7s, %3d%7s   ", i + starting_index, "Monster", i, d->Monsters[i + starting_index].y, "South", d->Monsters[i + starting_index].x, "West");
			}
			else
			{
				mvprintw(i+4, 10, "     %35s", "");
			}
		}
		input = getch();
		switch(input)
		{
			case 033: //ESC
			ext_menu = 1;
			break;
			case 0403: //UP
			starting_index = starting_index - 1 < 0 ? 0 : starting_index-1;
			break;
			case 0402: //DOWN
			starting_index = starting_index +1 > d->nummon ? starting_index : starting_index+1;
			break;
			default:
			mvprintw(19, 10, "\tWrong Input: %o", input);
			break;
		}
		if(ext_menu) break;
	}
}
void openCharacterMenu(struct Dungeon *d)
{
	mvprintw(19, 10, "\tCharactor Menu not supported yet");
}
void movePC(struct Dungeon *d, int y_dir, int x_dir)
{
	int x_goal = d->PC_x + x_dir;
	int y_goal = d->PC_y + y_dir;

	if (d->dungeon[y_goal][x_goal] == '>' || d->dungeon[y_goal][x_goal] == '<') {
	  onStairs = 1;
	  //return;
	}
	
	mvprintw(22, 1, "x_dir: %3d, y_dir: %3d     ", x_dir, y_dir);
	//Move if valid
	if(validSpace(d, y_goal, x_goal))
	{
		mvprintw(23, 1, "Valid Space");
		d->monsters[d->PC_y][d->PC_x] = 0;
		d->monsters[y_goal][x_goal] = '@';
		d->PC_x = x_goal;
		d->PC_y = y_goal;
	}
	else
	{
		mvprintw(23, 1, "Invalid Space");
	}
	
}
