#ifndef DUNGEONIO_H
#define DUNGEONIO_H

#include "heap.h"

#define HEIGHT 21
#define WIDTH 80
#define ROOM_NUM 6

#define isIntelligent 1
#define isTelepathic 2
#define isTunneling 4
#define isErratic 8

struct Room
{
	uint8_t x, y, w, h;
};

struct Stairway
{
	uint8_t x, y;
};

typedef struct monster
{
	char value; //Value on map
	uint8_t behavior; //Only first 4 bits matter
	uint8_t x,y, goal_x, goal_y;
	uint8_t isDead;
  uint8_t speed;
  int next_turn;
} monster_t;

struct Dungeon
{
	char fileType[12];
	uint32_t version, fileSize;
  uint8_t PC_x, PC_y, PC_isAlive, PC_room;
	uint8_t dungeon_hardness[HEIGHT][WIDTH];
	char dungeon[HEIGHT][WIDTH];
	char monsters[HEIGHT][WIDTH];
	uint16_t numRooms, numUpStairways, numDownStairways;
	struct Room *Rooms;
	struct Stairway *UpStairways;
	struct Stairway *DownStairways;
	heap_t *monster_heap;
	monster_t *Monsters;
	uint8_t nummon;
	uint8_t** dungeon_paths;
};

struct Path
{
	uint8_t PC_x, PC_y;
	char DistanceArray[HEIGHT][WIDTH];
};
//Load.c
struct Dungeon Load_Dungeon(char *FileName);

//DungeonGenerator.c
struct Dungeon Generate_Dungeon();

//Save.c
struct Dungeon Save_Dungeon(char *FileName, struct Dungeon *d);

//PathP1.c
uint8_t** Non_TunnelPath(struct Dungeon *d, int print, int goal_x, int goal_y);

//PathP2.c
uint8_t** TunnelPath(struct Dungeon *d, int print, int goal_x, int goal_y);
void printPaths(struct Dungeon *d);

//AddMonsters.c
heap_t AddMonsters(struct Dungeon *d, uint8_t nummon);
heap_t UpdateMonsters(struct Dungeon *d);
void printMapWithMonsters(struct Dungeon *d);

//Monsters_new.c
void AddMonsters_new(struct Dungeon *d);
void UpdateMonsters_new(struct Dungeon *d);
int validSpace(struct Dungeon *d, int y_goal, int x_goal);
#endif
