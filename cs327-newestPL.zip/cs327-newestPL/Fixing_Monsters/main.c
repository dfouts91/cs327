#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "Dungeonio.h"

struct Dungeon d;
struct Dungeon d2;
uint8_t nummon = 10;

int LOAD = 0;
int SAVE = 0;

int main(int argc, char *argv[])
{

	d = Load_Dungeon("saved_dungeons/00.rlg327");
	d.nummon = 10;
	AddMonsters_new(&d);
	printMapWithMonsters(&d);
	for(int i = 0; i < 10; i++)
	{
		printf("\n%d\n", i);
		UpdateMonsters_new(&d);
		printMapWithMonsters(&d);
	}
	
	
	return 0;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
  char *home = getenv("HOME");
  char *game_dir = ".rlg327";
  char *save_fold = "dungeon";
  char *path = malloc(strlen(home) + strlen(game_dir) + strlen(save_fold) + 2 + 1);
  sprintf(path, "%s/%s/%s", home, game_dir, save_fold);
  
  int i;
  //printf("Arguments: %d\n", argc);
  for (i = 1; i < argc; i++) {
    //printf("%s\n", argv[i]);
    if (!strcmp(argv[i], "--load")) {
      LOAD = 1;
    }
    if (!strcmp(argv[i], "--save")) {
      SAVE = 1;
    }
    if (!strcmp(argv[i], "--nummon")) {
      //printf("Made it here!\n");
      char *Nummon = argv[i+1];
      nummon = atoi(Nummon);
    }
  }
  //printf("Number of monsters is: %d\n", nummon);

  if (LOAD == 1) {
    d = Load_Dungeon(path);
  } else {
    d = Generate_Dungeon();
  }
  
  heap_t mon_heap = AddMonsters(&d, nummon);
  d.monster_heap = &mon_heap;// = AddMonsters(&d, nummon);
  printMapWithMonsters(&d);

  int counter = 0;
  while (counter < 4000 && d.PC_isAlive) {//d.PC_isAlive) {
    //printf("%dth time around\n", ++counter);
    mon_heap = UpdateMonsters(&d);
    d.monster_heap = &mon_heap; //= UpdateMonsters(&d);
    usleep(100000);
    //if (counter%20 == 0) {
      printMapWithMonsters(&d);
      //}
  }
  if (counter == 4000) {
    printf("\tYou survived 4000 turns, good job!\n");
  } else {
    printf("\n\t\tYou died! You lose! This was the final dungeon state ^\n\n\n");
  }
  //printMapWithMonsters(&d);

  //printf("nummon is %d\n", nummon);
  
  if (SAVE == 1) {
    Save_Dungeon(path, &d);
  }

  return 0;
  // if (argc == 1) {
    // d = Generate_Dungeon();
    // TunnelPath(&d, 1);
  // }
  // if (argc == 2) {

    /* char *home = getenv("HOME"); */
    /* char *rest = "/Documents/ComS327/cs327/A_1.03/saved_dungeons/00.rlg327"; */
    /* char *path = malloc(strlen(home) + strlen(rest) + 1); */
    /* sprintf(path, "%s%s", home, rest); */
	
	// //For those on Windose
    //d = Load_Dungeon("saved_dungeons/00.rlg327");
	 //d = Load_Dungeon("SaveTest/T1");
  //d = Generate_Dungeon();
	

	

	//printMapWithMonsters(&d);
	//mon_heap = UpdateMonsters(&d);
	//d.monster_heap = &mon_heap;
	//printMapWithMonsters(&d);
	//struct Dungeon *g = &d;
	//g->dungeon[5][5] = 'g';
	//printf("%d", d.PC_x);
	//printMapWithMonsters(&d);
	//Save_Dungeon("SaveTest/T3", &d);
	 
	//d2 = Load_Dungeon("SaveTest/T3");
	// return 0;
     //Non_TunnelPath(&d, 1);
  // }
  //commented out region below for testing of A_1.03

  // if (argc == 1) {
  	// //char *c = "saved_dungeons/welldone.rlg327";
  	// //struct Dungeon d = Load_Dungeon(c);
    // d = Generate_Dungeon();
  // } else if (argc >= 2) {
    // //if (!strcmp(argv[1], "--load") || !strcmp(argv[2], "--load")) {

    // /* char *home = getenv("HOME"); */
    // /* char *rest = "/Documents/ComS327/cs327/A_1.03/saved_dungeons/00.rlg327"; */
    // /* char *path = malloc(strlen(home) + strlen(rest) + 1); */
    // /* sprintf(path, "%s%s", home, rest); */
      // //}
    // if (argc == 2) {
      // if (!strcmp(argv[1], "--load")) {
  	// d = Load_Dungeon(path);
      // } else if (!strcmp(argv[1], "--save")) {
  	// d = Generate_Dungeon();
  	// Save_Dungeon(path, &d);
  	// //printf("Hello World!\n");
      // }
    // } else if (argc == 3) {
      // printf("Here!\n");
      // //Save_Dungeon(path, &d);
      // d = Load_Dungeon(path);
      // Save_Dungeon(path, &d);
    // }
  // }
  //Non_TunnelPath(&d, 1);
	//TunnelPath(&d, 1, d.PC_x, d.PC_y);
  
}
