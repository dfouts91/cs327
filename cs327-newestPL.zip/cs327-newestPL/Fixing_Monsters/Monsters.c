#include <stdio.h>
#include <stdlib.h>
#include <endian.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <limits.h>
#include "heap.h"
#include "Dungeonio.h"

#define DEBUG_AddMonsters_C if(0)
/*
TODO List:
	Fix Adding Monsters: Line 40
	Implement Update Monsters and add monster heap to dungeon struct
*/

static int32_t monster_cmp(const void *key, const void *with) 
{
  return ((monster_t *) key)->next_turn - ((monster_t *) with)->next_turn;
} 
heap_t AddMonsters(struct Dungeon *d, uint8_t nummon) 
{
	DEBUG_AddMonsters_C	printf("DEBUG_TAG_FOR AddMonsters.C IS SET\n");
	
	
	heap_t h;
	static uint32_t initialized = 0;
	
	if(!initialized)
	{
		initialized = 1;
	}
	
	heap_init(&h, monster_cmp, NULL);
	
	int num_monsters = 0;
	int room = rand()%d->numRooms;
	srand((unsigned) time (NULL));
	//monster_t *monsters = malloc(nummon*sizeof(monster_t));
	d->Monsters = malloc(nummon * sizeof(monster_t));
	d->monsters[d->PC_y][d->PC_x] = '@';
	
	//TODO Check if Monster is already in location
	while(num_monsters < nummon)
	{
	  

	  //make sure no monsters spawn on PC
	  while (room == d->PC_room) {
	    room = rand() % d->numRooms;
	  }
		
	  d->Monsters[num_monsters].x = (rand()% (d->Rooms[room].w)) + (d->Rooms[room].x);
	  d->Monsters[num_monsters].y = (rand()% (d->Rooms[room].h)) + (d->Rooms[room].y);
		
		//d->monsters[monsters[num_monsters].y][monsters[num_monsters].x] = 'M';

		d->Monsters[num_monsters].speed = rand()%15+5;

		d->Monsters[num_monsters].next_turn = 0 + (25 - d->Monsters[num_monsters].speed);
		
		d->Monsters[num_monsters].behavior = rand()% 16;
		
		if (d->Monsters[num_monsters].behavior >= 10) {
		  d->monsters[d->Monsters[num_monsters].y][d->Monsters[num_monsters].x] = (char)(97+(d->Monsters[num_monsters].behavior-10));
		  d->Monsters[num_monsters].value = (char)(97+(d->Monsters[num_monsters].behavior-10));
		} else {
		  d->monsters[d->Monsters[num_monsters].y][d->Monsters[num_monsters].x] = (char)(48+d->Monsters[num_monsters].behavior);
		  d->Monsters[num_monsters].value = (char)(48+(d->Monsters[num_monsters].behavior));
		}
		
		d->Monsters[num_monsters].isDead = 0;

		if (d->Monsters[num_monsters].behavior & isTelepathic) {
		  //printf("This is telepathic!\n");
		  d->Monsters[num_monsters].goal_x = d->PC_x;
		  d->Monsters[num_monsters].goal_y = d->PC_y;
		} else {
		  d->Monsters[num_monsters].goal_x = rand()%WIDTH;
		  d->Monsters[num_monsters].goal_y = rand()%HEIGHT;
		}
		
		heap_insert(&h, &d->Monsters[num_monsters]);
		
		num_monsters++;

		room = d->PC_room; //activate while loop
	}
	/* int z; */
	/* for (z = 0; z < nummon; z++) { */
	/*   printf("Monster id is %c, next turn is %d\n", d->Monsters[z].value, d->Monsters[z].next_turn); */
	/* } */

	return h;


	//NOTHING BELOW THIS GETS RAN
	
	//d->monster_heap = &h;
	//d->PC_x = 1;
	//d->PC_y = 1;
        //memcpy(d->monster_heap, &h, sizeof(&h));
	printf("size here is %d\n", d->monster_heap->size);


	/*
	  CODE FROM HERE WILL BE MOVED TO UPDATEMONSTERS ONCE WE CAN FIX THE BIG ISSUE
	*/

	monster_t *m;
	m = heap_remove_min(d->monster_heap);
	printf("m is : %d\n m.speed is %d\n", m->behavior, m->speed);

	//DEBUG_AddMonsters_C printf("Monster: count: %d\n", count);

	//DEBUG_AddMonsters_C printf("Behavior number is %d\n", m->behavior);
		
		DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Intelligent:", ((m->behavior & isIntelligent) ? 'y': 'n'));
		DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Telepathic:", ((m->behavior & isTelepathic) ? 'y': 'n'));
		DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Tunneling:", ((m->behavior & isTunneling) ? 'y': 'n'));
		DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Erratic:", ((m->behavior & isErratic) ? 'y': 'n'));
		
		DEBUG_AddMonsters_C printf("Starting Location: %d, %d\n", m->x, m->y);
		DEBUG_AddMonsters_C printf("Is Dead: %d\n", m->isDead);//((m->isDead) ? 'y': 'n'));
		DEBUG_AddMonsters_C printf("\n");
	
	//Note: This empties the monster heap.	
	// int count = 0;
	// while((m = heap_remove_min(&h)))
	// {
		// DEBUG_AddMonsters_C printf("Monster: count: %d\n", count);
		
		// DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Intelligent:", ((m->behavior & isIntelligent) ? 'y': 'n'));
		// DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Telepathic:", ((m->behavior & isTelepathic) ? 'y': 'n'));
		// DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Tunneling:", ((m->behavior & isTunneling) ? 'y': 'n'));
		// DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Erratic:", ((m->behavior & isErratic) ? 'y': 'n'));
		
		// DEBUG_AddMonsters_C printf("Starting Location: %d, %d\n", m->x, m->y);
		// DEBUG_AddMonsters_C printf("Is Dead: %d\n", ((m->isDead) ? 'y': 'n'));
		// DEBUG_AddMonsters_C printf("\n");
		// count++;
	// }
}
/*
Method to Update Monsters.  Not complete yet, not run yet.
*/
heap_t UpdateMonsters(struct Dungeon *d)
{
  //printf ("MAde it here?\n");
  static monster_t *m;
  heap_t new_heap;

  //printf("Made it here?\n");
	
  heap_init(&new_heap, monster_cmp, NULL);

	//new_heap = *d->monster_heap;
	//printf("MIH\n");
	
	int count = 0;

	//printf("MAde it here!2\n");
	
	//Pop from old heap, push to new
	//m = heap_remove_min(d->monster_heap);
	
	//printf("Size = %d \n", d->monster_heap->size);
	//memset(d->monsters, 0, sizeof(d->monsters));
	//while(d->monster_heap->size != 0)
	//{
		
	m = heap_remove_min(d->monster_heap);

	//printf("Monster whose turn it is: %c\n", m->value);
	
	if (!m->isDead) {
	  
		//Current Status
	  
		/* DEBUG_AddMonsters_C printf("Monster: count: %d\n", count); */

		/* DEBUG_AddMonsters_C printf("Behavior number is %d\n Speed is %d\n", m->behavior, m->speed); */
		
		/* DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Intelligent:", ((m->behavior & isIntelligent) ? 'y': 'n')); */
		/* DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Telepathic:", ((m->behavior & isTelepathic) ? 'y': 'n')); */
		/* DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Tunneling:", ((m->behavior & isTunneling) ? 'y': 'n')); */
		/* DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Erratic:", ((m->behavior & isErratic) ? 'y': 'n')); */
		
		/* DEBUG_AddMonsters_C printf("Starting Location: %d, %d\n", m->x, m->y); */
		/* DEBUG_AddMonsters_C printf("Is Dead: %d\n", ((m->isDead) ? 'y': 'n')); */
		/* DEBUG_AddMonsters_C printf("\n"); */
		
		//Clear monsters array //I am not sure why this isn't modifying the dungeon
		//d->dungeon[5][6] = 'g';
		//d->PC_x = 1;
		//d->PC_y = 1;
		
		//Start Movement here
		//printf("Made it here!");
		
		//Test Movement


	    int MOVED = 0;
	    
		//Some Monster Movement Logic, Code I Will Add Later

	    d->dungeon_paths = malloc(HEIGHT*sizeof(uint8_t *));
	    int q;
	    for (q = 0; q < HEIGHT; q++) {
	      d->dungeon_paths[q] = malloc(WIDTH*sizeof(uint8_t));
	    }

		int erratic = rand()%2;
	        int x_dir = rand()%3 - 1;
		int y_dir = rand()%3 - 1;
		int x_test, y_test;
		int lowest = INT_MAX;
		if (m->behavior & isErratic & !erratic) {
								  //printf("We shoudlny; be here\n");
								  //move in random direction
								  if (m->behavior & isTunneling) {
									d->dungeon_hardness[m->y+y_dir][m->x+x_dir] = d->dungeon_hardness[m->y+y_dir][m->x+x_dir] - 85;
									if (d->dungeon_hardness[m->y+y_dir][m->x+x_dir] < 0) {
									  d->dungeon_hardness[m->y+y_dir][m->x+x_dir] = 0;
									}
									if (d->dungeon_hardness[m->y+y_dir][m->x+x_dir] == 0) {
									  m->y = m->y + y_dir;
									  m->x = m->x + x_dir;
									  MOVED = 1;
									}
								  } else {
									if (d->dungeon_hardness[m->y+y_dir][m->x+x_dir] == 0) {
									  m->x = m->x + x_dir;
									  m->y = m->y + y_dir;
									  MOVED = 1;
									}
								  }
		} else {
		  if (m->behavior & isIntelligent) {
		    if (m->behavior & isTunneling) {
		      //PathP2
		      memcpy(d->dungeon_paths, TunnelPath(d, 0, m->goal_x, m->goal_y), HEIGHT*WIDTH*sizeof(uint8_t));
		      lowest = INT_MAX;
		      for (x_test = -1; x_test < 2; x_test++) {
			for (y_test = -1; y_test < 2; y_test++) {
			  if (d->dungeon_paths[m->y+y_test][m->x+x_test] < lowest) {
			    lowest = d->dungeon_paths[m->y+y_test][m->x+x_test];
			    x_dir = x_test;
			    y_dir = y_test;
			  }
			}
		      }
		      if (d->dungeon_hardness[m->y+y_dir][m->x+x_dir] < 85) {
			d->dungeon_hardness[m->y+y_dir][m->x+x_dir] = 0;
		      } else {
			d->dungeon_hardness[m->y+y_dir][m->x+x_dir] = d->dungeon_hardness[m->y+y_dir][m->x+x_dir] - 85;
		      }
		      //printf("hardness is %d\n", d->dungeon_hardness[m->y+y_dir][m->x+x_dir]);
		      if (d->dungeon_hardness[m->y+y_dir][m->x+x_dir] == 0) {
			m->y = m->y + y_dir;
			m->x = m->x + x_dir;
			MOVED = 1;
		      }
		      //printf("x_dir: %d, y_dir: %d\n", x_dir, y_dir);
		    } else {
		      //PathP1
		      memcpy(d->dungeon_paths, Non_TunnelPath(d, 0, m->goal_x, m->goal_y), HEIGHT*WIDTH*sizeof(uint8_t));
		      lowest = INT_MAX;
		      for (x_test = -1; x_test < 2; x_test++) {
			for (y_test = -1; y_test < 2; y_test++) {
			  if (d->dungeon_paths[m->y+y_test][m->x+x_test] < lowest) {
			    lowest = d->dungeon_paths[m->y+y_test][m->x+x_test];
			    x_dir = x_test;
			    y_dir = y_test;
			  }
			}
		      }
		      if (d->dungeon_hardness[m->y+y_dir][m->x+x_dir] < 85) {
			d->dungeon_hardness[m->y+y_dir][m->x+x_dir] = 0;
		      } else {
			d->dungeon_hardness[m->y+y_dir][m->x+x_dir] = d->dungeon_hardness[m->y+y_dir][m->x+x_dir] - 85;
		      }
		      //printf("hardness is %d\n", d->dungeon_hardness[m->y+y_dir][m->x+x_dir]);
		      if (d->dungeon_hardness[m->y+y_dir][m->x+x_dir] == 0) {
			m->y = m->y + y_dir;
			m->x = m->x + x_dir;
			MOVED = 1;
		      }
		      //printf("x_dir: %d, y_dir: %d\n", x_dir, y_dir);
		    }
		  } else {
			  
			  MOVED = 0;
			  x_dir = 0;
			  y_dir = 0;
			  
			  //Find Direction
			  x_dir = m->x > m->goal_x ? -1 : x_dir;
			  x_dir = m->x < m->goal_x ? 1 : x_dir;
			  y_dir = m->y > m->goal_y ? -1 : y_dir;
			  y_dir = m->y < m->goal_y ? 1 : y_dir;
			  
			  //printf("1. x_dir: %d, y_dir: %d\n", x_dir, y_dir);
			  //printf("Old location: x = %d, y = %d\n", m->x, m->y);
			  
			  //printf("\n%d\n", d->dungeon_hardness[m->y+y_dir][m->x+x_dir]);
		    if (m->behavior & isTunneling) {
		      //Euclidean direction
		      if (d->dungeon_hardness[m->y+y_dir][m->x+x_dir] < 85) {
			d->dungeon_hardness[m->y+y_dir][m->x+x_dir] = 0;
		      } else {
			d->dungeon_hardness[m->y+y_dir][m->x+x_dir] = d->dungeon_hardness[m->y+y_dir][m->x+x_dir] - 85;
		      }
		      //printf("hardness is %d\n", d->dungeon_hardness[m->y+y_dir][m->x+x_dir]);
		      if (d->dungeon_hardness[m->y+y_dir][m->x+x_dir] == 0) {
			m->y = m->y + y_dir;
			m->x = m->x + x_dir;
			MOVED = 1;
			//printf("New location: x = %d, y = %d\n", m->x, m->y);
		      }
		      //printf("2. x_dir: %d, y_dir: %d\n", x_dir, y_dir);
			  
				
			  
		    } else {
		      if(d->dungeon_hardness[m->y+y_dir][m->x+x_dir] != 0)
			{
			  x_dir = 0;
			  y_dir = 0;
			}
		      //Euclidean direction
		    }
			//Update X, Y, MOVED
			
		    /* //m->x += x_dir; */
		    /* 	  m->y += y_dir; */
		    /* 	  if(x_dir == 0 && y_dir == 0) */
		    /* 	  { */
		    /* 		  MOVED = 0; */
		    /* 	  } */
		    /* 	  else */
		    /* 	  { */
		    /* 		  MOVED = 1; */
		    /* 	  } */
		    /* 	  printf("x:%d, y:%d, MOVED: %d\n", x_dir, y_dir, MOVED); */
		  }
		}
	    
		//m->x++; //this is only necessary because logic below requires at least one move, breaks if monster is standing still. will fix later !FIXED
		//MOVED = 1;
		/* printf("value is %d\n",d->monsters[m->y][m->x]); */


		if (MOVED == 1) {
		  if (d->dungeon[m->y-y_dir][m->x-x_dir] == ' ') {
		    d->dungeon[m->y-y_dir][m->x-x_dir] = '#';
		  }
		}
		
		if (d->monsters[m->y][m->x] != 0 && MOVED != 0) {
		  if (d->monsters[m->y][m->x] == '@') {
		    //printf("Found PC!\n");
		    d->PC_isAlive = 0;
		  } else {
		    //printf("Found another monster!\n");
		    int found = 0;
		    int inc = 0;
		    while(!found) {
		      if (d->Monsters[inc].x == m->x && d->Monsters[inc].y == m->y) {
			d->Monsters[inc].isDead = 1;
			found = 1;
		      }
		      inc++;
		    }
		  }
		}
		d->monsters[m->y][m->x] = m->value;
		d->monsters[m->y-y_dir][m->x-x_dir] = 0;
		
		//End Movement here

		m->next_turn = m->next_turn + (1000/m->speed);//(25 - m->speed);
		
		//Updated Status
		//Behavior Should stay the same
		//DEBUG_AddMonsters_C printf("New Location: %d, %d\n", m->x, m->y);
		//DEBUG_AddMonsters_C printf("Is Dead: %d\n", ((m->isDead) ? 'y': 'n'));
		//DEBUG_AddMonsters_C printf("\n");
		count++;
		
		//Push to new heap.  Do not add dead monster to new heap.
		if (!m->isDead) {
		  //heap_insert(d->monster_heap, &m);
		  heap_insert(&new_heap, m);
		}

		//m = 
		//printf("This is where it should be\n");
		DEBUG_AddMonsters_C printf("Monster: count: %d\n", count);

		DEBUG_AddMonsters_C printf("Behavior number is %c\n Speed is %d\n", m->value, m->speed);
		
		DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Intelligent:", ((m->behavior & isIntelligent) ? 'y': 'n'));
		DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Telepathic:", ((m->behavior & isTelepathic) ? 'y': 'n'));
		DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Tunneling:", ((m->behavior & isTunneling) ? 'y': 'n'));
		DEBUG_AddMonsters_C printf("%-15s %c\n", "Is Erratic:", ((m->behavior & isErratic) ? 'y': 'n'));
		
		DEBUG_AddMonsters_C printf("Starting Location: %d, %d\n", m->x, m->y);
		DEBUG_AddMonsters_C printf("Is Dead: %d\n", ((m->isDead) ? 'y': 'n'));
		DEBUG_AddMonsters_C printf("\n");
	  }
	  while(d->monster_heap->size != 0) {
	    m = heap_remove_min(d->monster_heap);
	    heap_insert(&new_heap, m);
	  }
	  //}
	  //new_heap = *d->monster_heap;
	  //printf("Size of heap: %d\n", new_heap.size);
	  
	  int z = 0;
	  for(z= 0; z < HEIGHT; z++)
	  {
		  free(d->dungeon_paths[z]);
	  }
	  free(d->dungeon_paths);
	  
	  return new_heap;
	//d->monster_heap = &new_heap;
}

void printMapWithMonsters(struct Dungeon *d) 
{
	for(int i = 0; i < HEIGHT; i++)
	{
		for(int j = 0; j < WIDTH; j++)
		{
			printf("%c", (d->monsters[i][j] == 0 ? d->dungeon[i][j] : d->monsters[i][j]));
		}
		printf("\n");
	}
}
