#include <stdio.h>
#include <stdlib.h>
#include <endian.h>
#include <string.h>
#include <stdint.h>
#include "Dungeonio.h"

#define DEBUG_SAVE_C 1

struct Dungeon Save_Dungeon(char *FileName, struct Dungeon *d) {

	if(DEBUG_SAVE_C)	printf("DEBUG_TAG_FOR SAVE.C IS SET");
	
  FILE *fp;
  fp = fopen(FileName, "w");

  //filetype
  fwrite("RLG327-S2021", 12, 1, fp);

  //version
  int32_t version32 = htobe32(d->version);
  fwrite(&version32, 4, 1, fp);

  //filesize
  int32_t fileSize32 = htobe32(d->fileSize);
  fwrite(&fileSize32, 4, 1, fp);

  //player character
  fwrite(&d->PC_x, 1, 1, fp);
  fwrite(&d->PC_y, 1, 1, fp);

  //hardness
  //fwrite(&d->dungeon_hardness, 1, 1680, fp);
  int x, y;
  for (y = 0; y < HEIGHT; y++) {
    for (x = 0; x < WIDTH; x++) {
      fwrite(&d->dungeon_hardness[y][x], 1, 1, fp);
    }
  }
	printf("Number of rooms: %d\n", d->numRooms);
  //no of rooms
  int16_t numRooms16 = htobe16(d->numRooms);
  fwrite(&numRooms16, 2, 1, fp);

  //room locations
  int i;
  struct Room r;
  for (i = 0; i < d->numRooms; i++) {
    r = d->Rooms[i];
    fwrite(&r.x, 1, 1, fp);
    fwrite(&r.y, 1, 1, fp);
    fwrite(&r.w, 1, 1, fp);
    fwrite(&r.h, 1, 1, fp);
  }

  //up stairways
  int16_t numUpStairways16 = htobe16(d->numUpStairways);
  fwrite(&numUpStairways16, 2, 1, fp);

  //location up stairways
  int j;
  struct Stairway s;
  for (j = 0; j < d->numUpStairways; j++) {
    s = d->UpStairways[j];
    fwrite(&s.x, 1, 1, fp);
    fwrite(&s.y, 1, 1, fp);
  }
  
  //down stairways
  int16_t numDownStairways16 = htobe16(d->numDownStairways);
  fwrite(&numDownStairways16, 2, 1, fp);

  //location down stairways
  int k;
  struct Stairway s1;
  for (k = 0; k < d->numDownStairways; k++) {
    s1 = d->DownStairways[k];
    fwrite(&s1.x, 1, 1, fp);
    fwrite(&s1.y, 1, 1, fp);
  }
}
