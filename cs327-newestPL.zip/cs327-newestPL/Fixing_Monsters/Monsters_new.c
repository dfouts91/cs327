#include <stdio.h>
#include <stdlib.h>
#include <endian.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <limits.h>
#include "heap.h"
#include "Dungeonio.h"

void AddMonsters_new(struct Dungeon *d)
{
	//Setup Rand
	srand((unsigned) time (NULL));
	
	//Setup Array
	monster_t *monsters = malloc(sizeof(monster_t) * d->nummon);
	
	//Add PC
	d->monsters[d->PC_y][d->PC_x] = '@';
	
	uint8_t x, y, count, no_open_space, room;
	count = 0;
	no_open_space = 0;
	
	while(count < d->nummon)
	{
		//Find random spot inside a room
		room = rand() % d->numRooms;
		x = (rand()% (d->Rooms[room].w)) + (d->Rooms[room].x);
		y = (rand()% (d->Rooms[room].h)) + (d->Rooms[room].y);
		
		//Check for valid space
		if(d->monsters[y][x] != 0)
		{
			//Invalid space
			no_open_space++;
		}
		else
		{
			//Valid space
			
			//Setup Monster
			monsters[count].x = x;
			monsters[count].y = y;
			monsters[count].isDead = 0;
			monsters[count].behavior = rand()% 16;
			monsters[count].value = 'M';
			
			//Update Monsters map
			d->monsters[y][x] = monsters[count].value;
			
			//Update Count
			count++;
			no_open_space = 0;
		}
		if(no_open_space > 10)
		{
			break;
		}
	}
	d->nummon = count;
	d->Monsters = monsters;
}
void UpdateMonsters_new(struct Dungeon *d)
{
	uint8_t 
		count = 0, 
		isAlive = 0, 
		x_dir = 0,
		y_dir = 0,
		isInRoom = 0,
		goal_x,
		goal_y;
		
	/*
	Random = 0
	Path 1 = 1
	Path 2 = 2
	Linear = 3
	*/
	uint8_t method = 0;
	uint8_t erratic = rand() % 2;
	
	//Initialize new Monsters Array
	monster_t *new_ms = malloc(sizeof(monster_t) * d->nummon);
	
	while(count < d->nummon)
	{
		//Check if monster isAlive
		if(d->Monsters[count].isDead == 0)
		{
			//Copy Monster
			new_ms[isAlive].isDead = 0;
			new_ms[isAlive].behavior = d->Monsters[count].behavior;
			new_ms[isAlive].value = d->Monsters[count].value;
			
			//Find Goal
			goal_x = new_ms[isAlive].behavior & isTelepathic ? d->PC_x : rand()%WIDTH;
			goal_y = new_ms[isAlive].behavior & isTelepathic ? d->PC_y : rand()%HEIGHT;
				
			//Set Method
			if (new_ms[isAlive].behavior & isErratic & !erratic)
			{
				//Random
				method = 0;
			}
			else 
			{
				if (new_ms[isAlive].behavior & isIntelligent)
				{
					if (new_ms[isAlive].behavior & isTunneling)
					{
					//Path2
						method = 1; //Change to method = 2;
						printf("Tunneling Bandaid: DO NOT REMOVE WITHOUT FIXING");
					}
					else
					{
					//Path1
						method = 1;
					}
				}
				else
				{
				//Linear
					method = 3;
				}
			}

			switch(method)
			{
				case 0: //Random Movement
				{
					x_dir = rand() % 3 -1;
					y_dir = rand() % 3 -1;
				}
				break;
				case 1: //Path 1
				{
					uint8_t** Path = Non_TunnelPath(d, 0, goal_x, goal_y);
					
					int lowest = INT_MAX;
					
					for (int x_test = -1; x_test < 2; x_test++) 
					{
						for (int y_test = -1; y_test < 2; y_test++) 
						{
							if (Path[d->Monsters[count].y+y_test][d->Monsters[count].x+x_test] < lowest) 
							{
								lowest = Path[d->Monsters[count].y+y_test][d->Monsters[count].x+x_test];
								x_dir = x_test;
								y_dir = y_test;
							}
						}
					}
					free(Path);
			    }
				break;
				case 2: //Path 2
				{
					uint8_t** Path = TunnelPath(d, 0, goal_x, goal_y);
					printf("After Tunnel Method");
					int lowest = INT_MAX;
					
					for (int x_test = -1; x_test < 2; x_test++) 
					{
						for (int y_test = -1; y_test < 2; y_test++) 
						{
							if (Path[d->Monsters[count].y+y_test][d->Monsters[count].x+x_test] < lowest) 
							{
								lowest = Path[d->Monsters[count].y+y_test][d->Monsters[count].x+x_test];
								x_dir = x_test;
								y_dir = y_test;
							}
						}
					}
					free(Path);
				}
				break;
				case 3: //Linear
				{
					x_dir = 0;
					y_dir = 0;
					
					//Find Direction
					x_dir = d->Monsters[count].x > goal_x ? -1 : x_dir;
					x_dir = d->Monsters[count].x < goal_x ? 1 : x_dir;
					y_dir = d->Monsters[count].y > goal_y ? -1 : y_dir;
					y_dir = d->Monsters[count].y < goal_y ? 1 : y_dir;
				}
				break;
				default:
				break;
			}
			//Check Destination
			
			//Check outside walls
			if(d->Monsters[count].y+y_dir >= HEIGHT-1 || d->Monsters[count].y+y_dir <= 0)
			{
				y_dir = 0;
			}
			if(d->Monsters[count].x+x_dir >= WIDTH-1 || d->Monsters[count].x+x_dir <= 0)
			{
				x_dir = 0;
			}
			if(new_ms[isAlive].behavior & isTunneling)
			{
				if (d->dungeon_hardness[d->Monsters[count].y+y_dir][d->Monsters[count].x+x_dir] < 85)
				{
					d->dungeon_hardness[d->Monsters[count].y+y_dir][d->Monsters[count].x+x_dir] = 0;
					if (d->dungeon[d->Monsters[count].y-y_dir][d->Monsters[count].x-x_dir] == ' ') 
					{
						
						d->dungeon[d->Monsters[count].y-y_dir][d->Monsters[count].x-x_dir] = '#';
					}
				}
				else
				{
					d->dungeon_hardness[d->Monsters[count].y+y_dir][d->Monsters[count].x+x_dir] = d->dungeon_hardness[d->Monsters[count].y+y_dir][d->Monsters[count].x+x_dir] - 85;
					x_dir = 0;
					y_dir = 0;
				}
			}
			else
			{
				if (d->dungeon_hardness[d->Monsters[count].y+y_dir][d->Monsters[count].x+x_dir] != 0)
				{
					x_dir = 0;
					y_dir = 0;
				}
			}
			//Check for Monsters
			int fy = d->Monsters[count].y + y_dir;
			int fx = d->Monsters[count].x + x_dir;
			
			if(x_dir == 0 && y_dir == 0)
			{
				if(d->monsters[fy][fx] != 0)
				{
					if(d->monsters[fy][fx] == '@') //Found PC
					{
						d->PC_isAlive = 0;
						printf("Found PC");
					}
					else //Found Another Monster
					{
						//Monster still in old Que
						for(int i = count; i < d->nummon; i++)
						{
							if(d->Monsters[i].y == fy && d->Monsters[i].x == fx)
							{
								d->Monsters[i].isDead = 1;
								printf("Found Monster: %d, %d\n", fx, fy);
								break;
							}
						}
						//Monster in new Que
						for(int i = 0; i < isAlive; i++)
						{
							if(new_ms[i].y == fy && d->Monsters[i].x == fx)
							{
								new_ms[isAlive].isDead == 1;
								printf("Found Monster: %d, %d\n", fx, fy);
								break;
							}
						}
					}
				}
			}
			
			//Move Monster
			new_ms[isAlive].x = d->Monsters[count].x + x_dir;
			new_ms[isAlive].y = d->Monsters[count].y + y_dir;
			
			//Update Monsters grid
			d->monsters[new_ms[isAlive].y][new_ms[isAlive].x] = new_ms[isAlive].value;//Add new
			d->monsters[d->Monsters[count].y][d->Monsters[count].x] = 0; //Remove old
			
			isAlive++;
		}
		count++;
	}
	
	free(d->Monsters);
	d->Monsters = new_ms;
	d->nummon = isAlive;
	printf("Number of Monsters Alive: %d\n", isAlive);
}
