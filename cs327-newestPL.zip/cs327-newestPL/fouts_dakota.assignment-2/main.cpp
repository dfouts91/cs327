#include <stdio.h>
#include "zilch.h"

#define MAX_PLAYERS 4;

int main() {
  
  //printf("How many players will be playing?\n"); 

  roll();
  
  return 0;
}
