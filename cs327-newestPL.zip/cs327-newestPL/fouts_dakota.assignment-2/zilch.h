#include <stdio.h>


void play_game();
void roll();
