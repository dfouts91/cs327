#include <stdio.h>

#include "zilch.h"

#define MAX_PLAYERS 4;

int main() {

  play_game();
  
  return 0;
}
