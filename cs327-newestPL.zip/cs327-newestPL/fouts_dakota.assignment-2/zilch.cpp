#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void score(int arr[6]);

void play_game() {
  printf("Playing game\n");
  
}
  
void roll() {
  int dice[6] = {0, 0, 0, 0, 0, 0};
  srand((unsigned) time(NULL));

  int i;
  for (i = 0; i < 6; i++) {
    dice[i] = rand() % 6 + 1;
    printf("%d\n", dice[i]);
  }
  score(dice);
}

void score(int arr[6]) {
  int score = 0;
  int j;
  for (j = 0; j < 6; j++) {
    score += arr[j];
  }
  printf("score = %d\n", score);
}
 
