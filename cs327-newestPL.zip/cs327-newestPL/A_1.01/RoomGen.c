#include<stdio.h>
#include<stdlib.h>
#include<time.h>

#define HEIGHT 21
#define WIDTH 80
#define ROOM_NUM 6

char Map[HEIGHT][WIDTH];

struct Room {
  int xpos;
  int ypos;
  int width;
  int height;
};

struct Room rooms[ROOM_NUM];

int roomNum = 0;
	
void setup();
void printMap();
void generateMap();
void createRoom(int stairs);
void makePaths();

int main(int argc, char *argv[])
{	
	//Keep logic out of main.  
	//This will probably become a different file soon
	
	setup();
	generateMap();
	makePaths();
	printMap();
}
//Setup the seed for the random numbers
void setup()
{
	srand((unsigned) time(NULL));
}
//Print the current dungeon
void printMap()
{
	system("clear");
	
	printf("\n");
	printf("\n");
	
	int i, j;
	
	for(i = 0; i < HEIGHT; i++)
	{
		for(j = 0; j < WIDTH; j++)
		{
			printf("%c", Map[i][j]);
		}
		printf("\n");
	}
}
//Generate the dungeon layout
void generateMap()
{
	int i, j;
	
	for(i = 0; i < WIDTH; i++)
	{
		for(j = 0; j < HEIGHT; j++)
		{
			Map[j][i] = ' ';
		}
	}
	int r;
	for(r = 0; r < ROOM_NUM-2; r++)
	{
		createRoom(0);
	}
	createRoom(-1);
	createRoom(1);
}
/*
	Add a room
	@param int stairs
		1 Upward staircase
		-1 Downward staircase
		0 No staircases
*/
void createRoom(int stairs)
{
	int y_start = (rand() % HEIGHT);
	int x_start = (rand() % WIDTH);
	
	//Room size range: Width: 4-8, Height: 3-7
	int x_end = x_start + (rand() % 5) + 4;
	int y_end = y_start + (rand() % 5) + 3;
	
	//Check for valid room placement, else start over
	for(int x = x_start; x < x_end; x++)
	{
		for(int y = y_start; y < y_end; y++)
		{
			if(x == 0 || y == 0 || x == WIDTH-1 || y == HEIGHT -1)
			{
				createRoom(stairs);
				return;
			}
			if(Map[y][x] == '.' || Map[y+1][x] == '.' || Map[y-1][x] == '.')
			{
				createRoom(stairs);
				return;
			}
			if(Map[y][x+1] == '.' || Map[y][x-1] == '.')
			{
				createRoom(stairs);
				return;
			}
		}
	}
	
	//If you are here, room is valid
	
	//Place room
	for(int x = x_start; x < x_end; x++)
	{
		for(int y = y_start; y < y_end; y++)
		{
			Map[y][x] = '.';
		}
	}

	//Add to list of rooms
	struct Room r = {x_start, y_start, x_start-x_end, y_start-y_end};
	rooms[roomNum] = r;
	roomNum++;
	
	//Add stairs if applicable
	if(stairs == -1)
	{
		Map[y_start][x_start] = '<';
	}
	if(stairs == 1)
	{
		Map[y_start][x_start] = '>';
	}
}

//Generate paths to connect pre-made rooms 
void makePaths() {

  //Easy method: Go from top corner of one room to top corner of subsequent room
  int i;
  int x1, x2, y1, y2;
  struct Room r1, r2;

  //Cycle through rooms to connect
  for (i = 0; i < ROOM_NUM-1; i++) {
    
    r1 = rooms[i];
    r2 = rooms[i+1];
    y1 = r1.xpos;
    x1 = r1.ypos;
    y2 = r2.xpos;
    x2 = r2.ypos;

    int lat, vert;
    int finalX;

    lat = 1;
    vert = 1;

    if (x1 < x2) {
      while (x1+lat <= x2) {
	if (Map[x1+lat][y1] == ' ') {
	  Map[x1+lat][y1] = '#';
	}
	lat++;
      }
      finalX = x1+lat-1;
    } else {
      while (x1-lat >= x2) {
	if (Map[x1-lat][y1] == ' ') {
	  Map[x1-lat][y1] = '#';
	}
	lat++;
      }
      finalX = x1-lat+1;
    }
    if (y1 < y2) {
      while (y1+vert <= y2) {
	if (Map[finalX][y1+vert] == ' ') {
	  Map[finalX][y1+vert] = '#';
	}
	vert++;
      }
    } else {
      while (y1-vert >= y2) {
	if (Map[finalX][y1-vert] == ' ') {
	  Map[finalX][y1-vert] = '#';
	}
	vert++;
      }
    }
  }
}









