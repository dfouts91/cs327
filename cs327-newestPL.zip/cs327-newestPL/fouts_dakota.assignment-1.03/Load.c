#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "Dungeonio.h"

#define DEBUG_LOAD_C 0

uint16_t LitToBigEndian16(uint16_t x);
uint32_t LitToBigEndian32(uint32_t x);

struct Dungeon Load_Dungeon(char *FileName){

	struct Dungeon Dungeon_1;
	
	if(DEBUG_LOAD_C)	printf("DEBUG_TAG_FOR LOAD.C IS SET");

	FILE *fp;
	fp = fopen(FileName, "r");
	
	if(DEBUG_LOAD_C)	printf("\n\n");
	
	//File information
	fread(Dungeon_1.fileType, 12, 1, fp);
	if(DEBUG_LOAD_C)	printf("File Type: %s\n", Dungeon_1.fileType);
	
	fread(&Dungeon_1.version, 4, 1, fp);
	Dungeon_1.version = LitToBigEndian32(Dungeon_1.version);
	if(DEBUG_LOAD_C)	printf("Version: %d\n", Dungeon_1.version);
	
	fread(&Dungeon_1.fileSize, 4, 1, fp);
	Dungeon_1.fileSize = LitToBigEndian32(Dungeon_1.fileSize);
	if(DEBUG_LOAD_C)	printf("File Size: %d\n", Dungeon_1.fileSize);
	
	//Charactor Location
	fread(&Dungeon_1.PC_x, 1, 1, fp);
	fread(&Dungeon_1.PC_y, 1, 1, fp);
	/*if(DEBUG_LOAD_C)*/	printf("\nPC: %d, %d\n", Dungeon_1.PC_x, Dungeon_1.PC_y);
	
	for(int i = 0; i < HEIGHT; i++)
	{
		for(int j = 0; j < WIDTH; j++)
		{
			fread(&Dungeon_1.dungeon_hardness[i][j], 1, 1, fp);
			
			if(Dungeon_1.dungeon_hardness[i][j] == 0)
			{
				Dungeon_1.dungeon[i][j] = '#';
			}
			else
			{
				Dungeon_1.dungeon[i][j] = ' ';
			}
			//printf("Hardness at %d, %d is: %d\t", i, j, Dungeon_1.dungeon_hardness[i][j]);
		}
		//printf("\n \n");
	}
	//Rooms
	fread(&Dungeon_1.numRooms, 2, 1, fp);
	Dungeon_1.numRooms = LitToBigEndian16(Dungeon_1.numRooms);
	if(DEBUG_LOAD_C)	printf("\nNumber of Rooms: %d\n", Dungeon_1.numRooms);
	
	Dungeon_1.Rooms = malloc(Dungeon_1.numRooms * sizeof(struct Room));
	
	for(int i = 0; i < Dungeon_1.numRooms; i++)
	{
		fread(&Dungeon_1.Rooms[i].x, 1, 1, fp);
		fread(&Dungeon_1.Rooms[i].y, 1, 1, fp);
		fread(&Dungeon_1.Rooms[i].w, 1, 1, fp);
		fread(&Dungeon_1.Rooms[i].h, 1, 1, fp);
		
		if(DEBUG_LOAD_C)	printf("Room %2d, X: %4d, Y: %4d, W: %4d, H: %4d\n", i, Dungeon_1.Rooms[i].x, Dungeon_1.Rooms[i].y, Dungeon_1.Rooms[i].w, Dungeon_1.Rooms[i].h);
		
		for(int k = 0; k < Dungeon_1.Rooms[i].w; k++)
		{
			for(int j = 0; j < Dungeon_1.Rooms[i].h; j++)
			{
				Dungeon_1.dungeon[Dungeon_1.Rooms[i].y+j][Dungeon_1.Rooms[i].x+k] = '.';
			}
		}
	}
	
	//Up Stairways
	fread(&Dungeon_1.numUpStairways, 2, 1, fp);
	Dungeon_1.numUpStairways = LitToBigEndian16(Dungeon_1.numUpStairways);
	if(DEBUG_LOAD_C)	printf("\nNumber of Up Stairways: %d\n", Dungeon_1.numUpStairways);

	Dungeon_1.UpStairways = malloc(Dungeon_1.numUpStairways * sizeof(struct Stairway));
	
	for(int i = 0; i < Dungeon_1.numUpStairways; i++)
	{
		fread(&Dungeon_1.UpStairways[i].x, 1, 1, fp);
		fread(&Dungeon_1.UpStairways[i].y, 1, 1, fp);
		
		if(DEBUG_LOAD_C)	printf("Up Stairways %2d, X: %4d, Y: %4d\n", i, Dungeon_1.UpStairways[i].x, Dungeon_1.UpStairways[i].y);
		
		Dungeon_1.dungeon[Dungeon_1.UpStairways[i].y][Dungeon_1.UpStairways[i].x] = '<';
	}
	
	//Down Stairways
	fread(&Dungeon_1.numDownStairways, 2, 1, fp);
	Dungeon_1.numDownStairways = LitToBigEndian16(Dungeon_1.numDownStairways);
	if(DEBUG_LOAD_C)	printf("\nNumber of Down Stairways: %d\n", Dungeon_1.numDownStairways);
	
	Dungeon_1.DownStairways = malloc(Dungeon_1.numDownStairways * sizeof(struct Stairway));
	
	for(int i = 0; i < Dungeon_1.numDownStairways; i++)
	{
		fread(&Dungeon_1.DownStairways[i].x, 1, 1, fp);
		fread(&Dungeon_1.DownStairways[i].y, 1, 1, fp);
		
		if(DEBUG_LOAD_C)	printf("Down Stairways %2d, X: %4d, Y: %4d\n", i, Dungeon_1.DownStairways[i].x, Dungeon_1.DownStairways[i].y);
		
		Dungeon_1.dungeon[Dungeon_1.DownStairways[i].y][Dungeon_1.DownStairways[i].x] = '>';
	}
	
	Dungeon_1.dungeon[Dungeon_1.PC_y][Dungeon_1.PC_x] = '@';
	
	for(int i = 0; i < HEIGHT; i++)
	{
		for(int j = 0; j < WIDTH; j++)
		{
		  /*if(DEBUG_LOAD_C)*/	printf("%c", Dungeon_1.dungeon[i][j]);
		}
		/*if(DEBUG_LOAD_C)*/	printf("\n");
	}
	return Dungeon_1;
}

uint32_t LitToBigEndian32(uint32_t x)
{
	return (((x>>24) & 0x000000ff) | ((x>>8) & 0x0000ff00) | ((x<<8) & 0x00ff0000) | ((x<<24) & 0xff000000));
}
uint16_t LitToBigEndian16(uint16_t x)
{
	return (((x<<8) & 0xff00) | ((x>>8) & 0x00ff));
}
	
