#ifndef DUNGEONIO_H
#define DUNGEONIO_H

#define HEIGHT 21
#define WIDTH 80
#define ROOM_NUM 6

struct Room
{
	uint8_t x, y, w, h;
};

struct Stairway
{
	uint8_t x, y;
};

struct Dungeon
{
	char fileType[12];
	uint32_t version, fileSize;
	uint8_t PC_x, PC_y;
	uint8_t dungeon_hardness[HEIGHT][WIDTH];
	char dungeon[HEIGHT][WIDTH];
	uint16_t numRooms, numUpStairways, numDownStairways;
	struct Room *Rooms;
	struct Stairway *UpStairways;
	struct Stairway *DownStairways;
};

struct Path
{
	uint8_t PC_x, PC_y;
	char DistanceArray[HEIGHT][WIDTH];
};
//Load.c
struct Dungeon Load_Dungeon(char *FileName);

//DungeonGenerator.c
struct Dungeon Generate_Dungeon();

//Save.c
struct Dungeon Save_Dungeon(char *FileName, struct Dungeon *d);

//PathP1.c
void Non_TunnelPath(struct Dungeon *d, int print);

//PathP2.c
void TunnelPath(struct Dungeon *d, int print);
void printPaths(struct Dungeon *d);

#endif