#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include <stdint.h>
#include"Dungeonio.h"

//char Map[HEIGHT][WIDTH];

struct Dungeon Dungeon_1;

// struct Room {
  // int xpos;
  // int ypos;
  // int width;
  // int height;
// };

//struct Room rooms[ROOM_NUM];

int roomNum = 0;
	
//void setup();
void printMap();
void generateMap();
void createRoom(int stairs);
void makePaths();


struct Dungeon Generate_Dungeon()
{	
	srand((unsigned) time(NULL));
	
	//Dungeon_1.fileType = "RLG327-S2021";
	Dungeon_1.version = 0;
	
	generateMap();
	makePaths();
	printMap();
	
	return Dungeon_1;
}
// int main(int argc, char *argv[])
// {	
	// //Keep logic out of main.  
	// //This will probably become a different file soon
	
	// //setup();
	// generateMap();
	// makePaths();
	// printMap();
// }
//Setup the seed for the random numbers
// void setup()
// {
	// srand((unsigned) time(NULL));
// }
//Print the current dungeon
void printMap()
{
	system("clear");
	
	printf("\n");
	printf("\n");
	
	int i, j;
	
	for(i = 0; i < HEIGHT; i++)
	{
		for(j = 0; j < WIDTH; j++)
		{
			printf("%c", Dungeon_1.dungeon[i][j]);
		}
		printf("\n");
	}
	//for (i = 0; i < HEIGHT; i++) {
	  
}
//Generate the dungeon layout
void generateMap()
{
	int i, j;

	for(i = 0; i < WIDTH; i++)
	{
		for(j = 0; j < HEIGHT; j++)
		{
		  Dungeon_1.dungeon_hardness[j][i] = (rand() % 253)+1;
			Dungeon_1.dungeon[j][i] = ' ';
			
			if(i == 0 || j == 0 || i == WIDTH-1 || i == HEIGHT-1)
			{
				Dungeon_1.dungeon_hardness[j][i] = 255;
			}
		}
	}
	
	Dungeon_1.Rooms = malloc(Dungeon_1.numRooms * sizeof(struct Room));
	
	Dungeon_1.numUpStairways = 1;
	Dungeon_1.numDownStairways = 1;
	Dungeon_1.UpStairways = malloc(Dungeon_1.numUpStairways * sizeof(struct Stairway));
	Dungeon_1.DownStairways = malloc(Dungeon_1.numDownStairways * sizeof(struct Stairway));
	
	
	int r;
	Dungeon_1.numRooms = ROOM_NUM;
	printf("Num of rooms: %d\n", Dungeon_1.numRooms);
	for(r = 0; r < ROOM_NUM-2; r++)
	{
		createRoom(0);
	}
	createRoom(-1);
	createRoom(1);
	
	printf("Testpoint\n");
	
	

	//printf("Testpoint\n");
	//Place player character
	struct Room pr = Dungeon_1.Rooms[0];
	Dungeon_1.PC_x = pr.x;
	Dungeon_1.PC_y = pr.y;
	Dungeon_1.dungeon[pr.y][pr.x] = '@';
}
/*
	Add a room
	@param int stairs
		1 Upward staircase
		-1 Downward staircase
		0 No staircases
*/
void createRoom(int stairs)
{
	int y_start = (rand() % HEIGHT);
	int x_start = (rand() % WIDTH);
	
	//Room size range: Width: 4-8, Height: 3-7
	int x_end = x_start + (rand() % 5) + 4;
	int y_end = y_start + (rand() % 5) + 3;
	
	//Check for valid room placement, else start over
	for(int x = x_start; x < x_end; x++)
	{
		for(int y = y_start; y < y_end; y++)
		{
			if(x == 0 || y == 0 || x == WIDTH-1 || y == HEIGHT -1)
			{
				createRoom(stairs);
				return;
			}
			if(Dungeon_1.dungeon[y][x] == '.' || Dungeon_1.dungeon[y+1][x] == '.' || Dungeon_1.dungeon[y-1][x] == '.')
			{
				createRoom(stairs);
				return;
			}
			if(Dungeon_1.dungeon[y][x+1] == '.' || Dungeon_1.dungeon[y][x-1] == '.')
			{
				createRoom(stairs);
				return;
			}
		}
	}
	
	//If you are here, room is valid
	
	//Place room
	for(int x = x_start; x < x_end; x++)
	{
		for(int y = y_start; y < y_end; y++)
		{
			Dungeon_1.dungeon[y][x] = '.';
		}
	}

	//Add to list of rooms
	struct Room r = {x_start, y_start, abs(x_start-x_end), abs(y_start-y_end)};
	Dungeon_1.Rooms[roomNum] = r;
	roomNum++;
	
	//Add stairs if applicable
	if(stairs == -1)
	{
		Dungeon_1.dungeon[y_start][x_start] = '>';
		struct Stairway down1 = {x_start, y_start};
		Dungeon_1.DownStairways[0] = down1;
	}
	if(stairs == 1)
	{
		Dungeon_1.dungeon[y_start][x_start] = '<';
		struct Stairway up1 = {x_start, y_start};
		Dungeon_1.UpStairways[0] = up1;
	}
}

//Generate paths to connect pre-made rooms 
void makePaths() {

  //Easy method: Go from top corner of one room to top corner of subsequent room
  int i;
  int x1, x2, y1, y2;
  struct Room r1, r2;

  //Cycle through rooms to connect
  for (i = 0; i < ROOM_NUM-1; i++) {
    
    r1 = Dungeon_1.Rooms[i];
    r2 = Dungeon_1.Rooms[i+1];
    y1 = r1.x;
    x1 = r1.y;
    y2 = r2.x;
    x2 = r2.y;

    int lat, vert;
    int finalX;

    lat = 1;
    vert = 1;

    if (x1 < x2) {
      while (x1+lat <= x2) {
	if (Dungeon_1.dungeon[x1+lat][y1] == ' ') {
	  Dungeon_1.dungeon[x1+lat][y1] = '#';
	  Dungeon_1.dungeon_hardness[x1+lat][y1] = 0;
	}
	lat++;
      }
      finalX = x1+lat-1;
    } else {
      while (x1-lat >= x2) {
	if (Dungeon_1.dungeon[x1-lat][y1] == ' ') {
	  Dungeon_1.dungeon[x1-lat][y1] = '#';
	  Dungeon_1.dungeon_hardness[x1-lat][y1] = 0;
	}
	lat++;
      }
      finalX = x1-lat+1;
    }
    if (y1 < y2) {
      while (y1+vert <= y2) {
	if (Dungeon_1.dungeon[finalX][y1+vert] == ' ') {
	  Dungeon_1.dungeon[finalX][y1+vert] = '#';
	  Dungeon_1.dungeon_hardness[finalX][y1+vert] = 0;
	}
	vert++;
      }
    } else {
      while (y1-vert >= y2) {
	if (Dungeon_1.dungeon[finalX][y1-vert] == ' ') {
	  Dungeon_1.dungeon[finalX][y1-vert] = '#';
	  Dungeon_1.dungeon_hardness[finalX][y1-vert] = 0;
	}
	vert++;
      }
    }
  }
}
