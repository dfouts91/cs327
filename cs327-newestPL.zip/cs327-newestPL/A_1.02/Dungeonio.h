#ifndef DUNGEONIO_H
#define DUNGEONIO_H

#define HEIGHT 21
#define WIDTH 80
#define ROOM_NUM 6

struct Room
{
	uint8_t x, y, w, h;
};

struct Stairway
{
	uint8_t x, y;
};

struct Dungeon
{
	char fileType[12];
	uint32_t version, fileSize;
	uint8_t PC_x, PC_y;
	uint8_t dungeon_hardness[HEIGHT][WIDTH];
	char dungeon[HEIGHT][WIDTH];
	uint16_t numRooms, numUpStairways, numDownStairways;
	struct Room *Rooms;
	struct Stairway *UpStairways;
	struct Stairway *DownStairways;
};
	
struct Dungeon Load_Dungeon(char *FileName);
struct Dungeon Generate_Dungeon();
struct Dungeon Save_Dungeon(char *FileName, struct Dungeon *d);
//void printMap();
//uint32_t LitToBigEndian32(uint32_t x); //Moved to Load.c, should not be global
//uint16_t LitToBigEndian16(uint16_t x); //Moved to Load.c, should not be global

#endif