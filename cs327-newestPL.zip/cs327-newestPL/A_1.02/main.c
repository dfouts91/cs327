#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "Dungeonio.h"

struct Dungeon d;

int main(int argc, char *argv[])
{

  if (argc == 1) {
	//char *c = "saved_dungeons/welldone.rlg327";
	//struct Dungeon d = Load_Dungeon(c);
    d = Generate_Dungeon();
  } else if (argc >= 2) {
    //if (!strcmp(argv[1], "--load") || !strcmp(argv[2], "--load")) {
    char *home = getenv("HOME");
    char *game_dir = ".rlg327";
    char *save_fold = "dungeon";
    char *path = malloc(strlen(home) + strlen(game_dir) + strlen(save_fold) + 2 + 1);
    sprintf(path, "%s/%s/%s", home, game_dir, save_fold);
      //}
    if (argc == 2) {
      if (!strcmp(argv[1], "--load")) {
	d = Load_Dungeon(path);
      } else if (!strcmp(argv[1], "--save")) {
	d = Generate_Dungeon();
	Save_Dungeon(path, &d);
	//printf("Hello World!\n");
      }
    } else if (argc == 3) {
      printf("Here!\n");
      //Save_Dungeon(path, &d);
      d = Load_Dungeon(path);
      Save_Dungeon(path, &d);
    }
  }
}
