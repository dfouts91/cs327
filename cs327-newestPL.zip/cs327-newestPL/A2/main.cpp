#include<stdio.h>
#include<stdlib.h>
#include<ncurses.h>
#include<time.h>

int main()
{
	initscr();
	noecho();
	srand(time(NULL));
	char hand_num = 6;
	char hand[6];
	char input;
	
	int score = 0, round_total = 0;
	
	char i;
	
	mvprintw(2, 2, "Score: %d", score);
	mvprintw(4, 2, "Round Total: %d", round_total);
	int r;
	for(r = 0; r < 6; r++)
	{
		mvprintw(5+r, 2, "R%d: %d", r+1, 0);
	}
	mvprintw(6+r, 2, "Current Dice: ");
	
	for(i = 0; i < hand_num; i++)
	{
		hand[i] = (rand() % 6) + 1;
		printw("%d  ", hand[i]);
	}
	mvprintw(8+r, 2, "Pick which dice you would like to keep(1-6).  End with x\n");
	i = 0;
	//Add bit field
	while(1)
	{
		input = getch();
		if(input == 'x')
		{
			break;
		}
		input -= '0';

		if(input > 6 || input < 1)
		{
			mvprintw(10+r, 2, "Invalid Input");
		}
		else
		{
			mvprintw(10+r, 2, "             ");
			mvprintw(9+r, 2+(i*2), "%d", hand[input-1]);
		    i++;
		}
	}
	
	refresh();
	getch();
	endwin();
	echo();
	return 0;
}
