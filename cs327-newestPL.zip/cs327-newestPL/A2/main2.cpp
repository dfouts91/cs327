#include<stdio.h>
#include<stdlib.h>
#include<ncurses.h>
#include<time.h>

void setupNcurses();
void setupGame();
int roll();
int score();
void cleanup();

int numPlayers;
int dice[6];
int dice_score[6];
int player_scores[4];
int not_done = 1;
int turn = numPlayers;
int main()
{
	setupNcurses();
	setupGame();
	dice[0] = 1;
	dice[1] = 1;
	dice[2] = 1;
	dice[3] = 1;
	dice[4] = 1;
	dice[5] = 1;
	while (not_done) {
	    
	    mvprintw(2,2, "P 1: %d", player_scores[0]);
	    mvprintw(2,25, "P 2: %d", player_scores[1]);
	    mvprintw(3,2, "P 3: %d", player_scores[2]);
	    mvprintw(3,25, "P 4: %d", player_scores[3]);
	    //roll();
	    player_scores[turn % numPlayers] += roll();
	    if (player_scores[turn % numPlayers] >= 10000) {
	      printf("Made it here!\n");
	      break;
	    }
	    turn++;
	    refresh();
	}

	int winner;
	int zz;
	for (zz = 0; zz < 4; zz++) {
	  if (player_scores[zz] >= 10000) {
	    winner = zz;
	  }
	}
	clear();
	mvprintw(15, 20, "Player %d wins with a score of: %d!!", winner+1, player_scores[winner]);
	
	cleanup();
	return 0;
}
void setupNcurses()
{
	initscr();
	noecho();
	curs_set(0);
}
void setupGame()
{
	srand(time(NULL));
	mvprintw(2,2, "How many players are playing? Max: 4");
	
	refresh();
	numPlayers = getch() - '0';

	int z;
	for (z = 0 ; z < 4; z++) {
	  player_scores[z] = 0;
	}
	
	clear();
	
	mvprintw(2,2, "P 1: 0");
	mvprintw(2,25, "P 2: 0");
	mvprintw(3,2, "P 3: 0");
	mvprintw(3,25, "P 4: 0");
	refresh();	
}
int roll()
{
  //printf("turn = %d, numPLayers = %d, turn mod num = %d\n", turn, numPlayers, turn%numPlayers); 
    mvprintw(5,5, "Player %d's turn: Press space to roll, Q to end your turn", 1+(turn % numPlayers));

	int total_score = 0;
	int ongoing;
	while (ongoing) {
	  
	  refresh();
	  int roll = getch();
	  if (roll == 'Q') {
	    break;
	  }
	  int i = 0;
	  int round = 1 + turn/numPlayers;
	  int offset_score = 12;
	  int num_scoring = 0;
	
	  int offset = 0;
	  for(i = 0; i < 6; i++)
	    {
	      //if(dice[i] != 0)
	      //{
		  dice[i] = (rand() % 6) + 1;
		  //dice[i] = 6;
		  dice_score[i] = 0;
		  mvprintw(6 + round, 18 + offset, "%d", dice[i]);
		  offset += 2;
		  //}
	    }
	  mvprintw(6 + round,5, "Select the dice you would like to score (in order, starting at 1), Press x when done. At least one die must be chosen per round to continue");
	  int input;
	  while(1)
	    {
	      offset = 0;
	      mvprintw(7 +round,2, "Current Dice:                                                   ");
	      for(i = 0; i < 6; i++)
		{
		  if(dice[i] != 0)
		    {				
		      mvprintw(7 + round, 18 + offset, "%d", dice[i]);
		      offset += 2;
		    } else {
		    mvprintw(7 + round, 18 + offset, " ");
		    offset += 2;
		  }
		}
	      offset = 2;
	      mvprintw(5+round, 5, "Round %d:                                        ", round);
	      for(i = 0; i < 6; i++)
		{
		  if(dice_score[i] != 0)
		    {				
		      mvprintw(5 + round, 12 + offset, "%d", dice_score[i]);
		      offset += 2;
		    }
		}
	      input = getch();
	      if(input == 'x' || input == 'Q')
		{
		  mvprintw(22, 25, "Press Q to end turn");
		  break;
		}
	      input -= '0';
	      mvprintw(10,10, "%d", input);
	      if (input >= 1 && input <= 6) {
		mvprintw(10, 10 + 2, "                            ");
		dice_score[num_scoring] = dice[input-1];
		num_scoring++;
		dice[input-1] = 0;
		//break;
	      } else {
		mvprintw(10, 10 + 2, "Invalid input! Try again");
	      }
	      // for(; j < 6; j++)
	      // {
	      // 	if(j == input && input != 0)
	      // 	{
	      // 		dice_score[num_scoring] = dice[j];
	      // 		num_scoring++;
	      // 		dice[j] = 0;
	      // 		break;
	      // 	}
	      // }
	    }
	  int jj;
	  int none = 1;
	  for (jj = 0; jj < 6; jj++) {
	    if (dice_score[jj] != 0) {
	      none = 0;
	    }
	  }
	  if (none) { //no dice chosen
	    mvprintw(22, 25, "No dice chosen, your turn is over!");
	    break;
	  }
	  total_score += score();
	  refresh();
	}
	clear();
	return total_score;
}
int score()
{
  int totals[6];
  int k;
  for (k = 0; k < 6; k++) {
    totals[k] = 0;
  }
  // int Ones = 0;
  // int Twos = 0;
  // int Threes = 0;
  // int Fours = 0;
  // int Fives = 0;
  // int Sixes = 0;
  int j = 0;
  for (j = 0; j < 6; j++) {
    switch(dice_score[j]) {

    case 1:
      totals[0]++;
      break;

    case 2:
      totals[1]++;
      break;

    case 3:
      totals[2]++;
      break;

    case 4:
      totals[3]++;
      break;

    case 5:
      totals[4]++;
      break;

    case 6:
      totals[5]++;
      break;
    }
  }

  int ii;
  for(ii = 0; ii < 6; ii++)
  {
	 	mvprintw(20, 60 + ii * 2, "%d", dice_score[ii]);
		mvprintw(21, 60 + ii * 2, "%d", totals[ii]); 
  }
  int score = 0;
  int straight = 1;
  int three_pair = 0;
  int l;
  for (l = 0; l < 6; l++) {
    if (totals[l] != 1) {
      straight = 0;
    }
  }
  if (straight) {
    //mvprintw(17, 60, "MAde it here! straight!\n");
    score = 1500;
    return score;
  }
  int ll;
  for (ll = 0; ll < 6; ll++) {
    if (totals[ll] == 2) {
      three_pair++;
    }
  }
  if (three_pair == 3) {
    //mvprintw(17, 60, "MAde it here! three pair!\n");
    score = 1500;
    return score;
  }
  int kl;
  for (kl = 0; kl < 6; kl++) {
    if (totals[kl] == 6) {
      score = 10000;
      return score;
    } else if (totals[kl] >= 3 && kl != 0) {
      //mvprintw(17, 60, "MAde it here! Not one!\n");
      score = (totals[kl]-2)*100*(kl+1);
      return score;
    } else if (totals[kl] >= 3) {
      //mvprintw(17, 60, "MAde it here! One!\n");
      score = 1000 * (totals[kl]-2);
      return score;
    }
  }
  score += totals[0]*100 + totals[4]*50;
  //score = 100;
  //mvprintw(22, 60, "Score for this round: %d Press space to roll again", score);
  return score;
}
void cleanup()
{
	getch();
	endwin();
	echo();
}
